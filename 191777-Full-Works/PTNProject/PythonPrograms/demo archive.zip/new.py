f=open("demo1.txt", "r")
contents =f.read()
